# Beginner setup checklist

1. Create a Supabase project and save the Project URL and public anon/publishable key.
2. Copy `.env.example` to `.env` and fill in the two `EXPO_PUBLIC_...` values.
3. Run the SQL migration in the Supabase SQL Editor.
4. Turn on email confirmation in Supabase Auth.
5. On a computer, run `npm install` and `npx expo start`.
6. Open Expo Go on your Android phone and scan the QR code.
7. Register with an email you can access and a strong unique password.

If you only have an Android phone and no computer, tell me that first; setup steps will be different. Do not share passwords or secret service keys in chat.
