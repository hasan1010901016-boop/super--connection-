import React, { useEffect, useState } from 'react';
import { Alert, ActivityIndicator, SafeAreaView, ScrollView, StyleSheet, Text, TextInput, TouchableOpacity, View, Image } from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import * as Notifications from 'expo-notifications';
import * as Device from 'expo-device';
import { Session } from '@supabase/supabase-js';
import { supabase } from '../lib/supabase';

const blue = '#246BFD';
type Tab = 'Feed' | 'Friends' | 'Messages' | 'Privacy';

export default function App() {
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);
  const [mode, setMode] = useState<'signin' | 'signup'>('signup');
  const [email, setEmail] = useState(''); const [password, setPassword] = useState('');
  const [username, setUsername] = useState(''); const [tab, setTab] = useState<Tab>('Feed');
  const [posts, setPosts] = useState<any[]>([]); const [draft, setDraft] = useState('');
  const [people, setPeople] = useState<any[]>([]); const [requests, setRequests] = useState<any[]>([]);
  const [conversations, setConversations] = useState<any[]>([]); const [activeConversation, setActiveConversation] = useState<string | null>(null);
  const [messages, setMessages] = useState<any[]>([]); const [messageDraft, setMessageDraft] = useState('');
  const [privateProfile, setPrivateProfile] = useState(false); const [allowRequests, setAllowRequests] = useState(true);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!supabase) { setLoading(false); return; }
    supabase.auth.getSession().then(({ data }) => { setSession(data.session); setLoading(false); });
    const { data: listener } = supabase.auth.onAuthStateChange((_event, next) => setSession(next));
    return () => listener.subscription.unsubscribe();
  }, []);

  useEffect(() => { if (session && supabase) { loadFeed(); registerPushToken(); } }, [session]);
  useEffect(() => { if (session && tab === 'Friends') loadFriends(); if (session && tab === 'Messages') loadConversations(); }, [session, tab]);
  useEffect(() => {
    if (!supabase || !activeConversation) return;
    loadMessages(activeConversation);
    const channel = supabase.channel('chat-' + activeConversation).on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages', filter: `conversation_id=eq.${activeConversation}` }, payload => setMessages(old => old.some(m => m.id === (payload.new as any).id) ? old : [...old, payload.new])).subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [activeConversation]);

  async function authenticate() {
    if (!supabase) return Alert.alert('Setup required', 'Create a Supabase project and copy values into .env first.');
    if (!email.trim() || password.length < 8) return Alert.alert('Check details', 'Enter an email and a password of at least 8 characters.');
    setBusy(true);
    try {
      if (mode === 'signup') {
        if (username.trim().length < 3) { setBusy(false); return Alert.alert('Choose a username', 'Use at least 3 characters.'); }
        const { error } = await supabase.auth.signUp({ email: email.trim(), password, options: { data: { username: username.trim() } } });
        if (error) throw error;
        Alert.alert('Check your email', 'If email confirmation is enabled, open the confirmation link before signing in.');
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email: email.trim(), password }); if (error) throw error;
      }
    } catch (e: any) { Alert.alert('Could not continue', e.message ?? 'Please try again.'); } finally { setBusy(false); }
  }

  async function loadFeed() { if (!supabase) return; const { data, error } = await supabase.from('posts').select('id,body,media_path,created_at,user_id,profiles(username,display_name,avatar_url)').order('created_at', { ascending: false }).limit(50); if (error) { console.warn(error.message); return; } const withUrls = await Promise.all((data ?? []).map(async p => { if (!p.media_path) return p; const { data: signed } = await supabase!.storage.from('post-media').createSignedUrl(p.media_path, 3600); return { ...p, media_url: signed?.signedUrl ?? null }; })); setPosts(withUrls); }
  async function publish() {
    if (!supabase || !session || !draft.trim()) return;
    const { error } = await supabase.from('posts').insert({ user_id: session.user.id, body: draft.trim() });
    if (error) Alert.alert('Post failed', error.message); else { setDraft(''); loadFeed(); }
  }
  async function uploadMedia() {
    if (!supabase || !session) return;
    const perm = await ImagePicker.requestMediaLibraryPermissionsAsync(); if (!perm.granted) return Alert.alert('Permission needed', 'Allow access to select a photo or video.');
    const result = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ['images', 'videos'], allowsEditing: false, quality: 0.85 }); if (result.canceled || !result.assets[0]) return;
    const asset = result.assets[0];
    if (asset.fileSize && asset.fileSize > 25 * 1024 * 1024) return Alert.alert('File too large', 'Choose a file smaller than 25 MB.');
    try {
      setBusy(true); const response = await fetch(asset.uri); const blob = await response.blob();
      const ext = (asset.fileName?.split('.').pop() || (asset.type === 'video' ? 'mp4' : 'jpg')).toLowerCase().replace(/[^a-z0-9]/g, '') || 'jpg';
      const path = `${session.user.id}/${Date.now()}.${ext}`;
      const { error: uploadError } = await supabase.storage.from('post-media').upload(path, blob, { contentType: asset.mimeType || (asset.type === 'video' ? 'video/mp4' : 'image/jpeg'), upsert: false });
      if (uploadError) throw uploadError;
      const { error } = await supabase.from('posts').insert({ user_id: session.user.id, body: draft.trim(), media_path: path });
      if (error) throw error; setDraft(''); await loadFeed();
    } catch (e: any) { Alert.alert('Upload failed', e.message ?? 'Try again.'); } finally { setBusy(false); }
  }
  async function loadFriends() {
    if (!supabase || !session) return;
    const [{ data: profiles }, { data: req }] = await Promise.all([
      supabase.from('profiles').select('id,username,display_name').neq('id', session.user.id).limit(50),
      supabase.from('friend_requests').select('id,sender_id,receiver_id,status,profiles!friend_requests_sender_id_fkey(username,display_name)').eq('receiver_id', session.user.id).eq('status', 'pending')
    ]);
    setPeople((profiles ?? []).filter(p => p.id !== session.user.id)); setRequests(req ?? []);
  }
  async function sendFriendRequest(userId: string) { if (!supabase || !session) return; const { error } = await supabase.from('friend_requests').insert({ sender_id: session.user.id, receiver_id: userId }); if (error) Alert.alert('Request not sent', error.message); else { Alert.alert('Sent', 'Friend request sent.'); loadFriends(); } }
  async function answerRequest(id: string, status: 'accepted' | 'rejected') { if (!supabase) return; const { error } = await supabase.from('friend_requests').update({ status }).eq('id', id); if (error) Alert.alert('Could not update', error.message); else loadFriends(); }
  async function loadConversations() {
    if (!supabase || !session) return;
    const { data, error } = await supabase.from('conversation_members').select('conversation_id,conversations(id,created_at)').eq('user_id', session.user.id);
    if (error) console.warn(error.message); else setConversations(data ?? []);
  }
  async function loadMessages(id: string) { if (!supabase) return; const { data, error } = await supabase.from('messages').select('id,conversation_id,sender_id,body,created_at').eq('conversation_id', id).order('created_at').limit(100); if (!error) setMessages(data ?? []); }
  async function sendMessage() { if (!supabase || !session || !activeConversation || !messageDraft.trim()) return; const body = messageDraft.trim(); setMessageDraft(''); const { error } = await supabase.from('messages').insert({ conversation_id: activeConversation, sender_id: session.user.id, body }); if (error) { setMessageDraft(body); Alert.alert('Message failed', error.message); } }
  async function reportUser(userId: string) { if (!supabase || !session) return; const { error } = await supabase.from('reports').insert({ reporter_id: session.user.id, target_user_id: userId, reason: 'other', details: 'Reported from member list' }); Alert.alert(error ? 'Report failed' : 'Report submitted', error?.message ?? 'Moderators can review this report.'); }
  async function blockUser(userId: string) { if (!supabase || !session) return; const { error } = await supabase.from('blocks').insert({ blocker_id: session.user.id, blocked_id: userId }); Alert.alert(error ? 'Could not block' : 'User blocked', error?.message ?? 'Their content should no longer be shown to you.'); if (!error) loadFriends(); }
  async function savePrivacy() { if (!supabase || !session) return; const { error } = await supabase.from('profiles').update({ is_private: privateProfile, allow_friend_requests: allowRequests }).eq('id', session.user.id); Alert.alert(error ? 'Not saved' : 'Privacy saved', error?.message ?? 'Your preferences were saved.'); }
  async function registerPushToken() {
    if (!supabase || !session || !Device.isDevice) return;
    const permission = await Notifications.getPermissionsAsync(); let status = permission.status;
    if (status !== 'granted') status = (await Notifications.requestPermissionsAsync()).status;
    if (status !== 'granted') return;
    try { const token = (await Notifications.getExpoPushTokenAsync()).data; await supabase.from('device_tokens').upsert({ user_id: session.user.id, expo_push_token: token }, { onConflict: 'expo_push_token' }); } catch (e) { console.warn('Push token setup:', e); }
  }

  if (loading) return <SafeAreaView style={s.center}><ActivityIndicator size="large" color={blue}/><Text style={s.muted}>Loading Super Connection…</Text></SafeAreaView>;
  if (!session) return <SafeAreaView style={s.safe}><ScrollView contentContainerStyle={s.auth}><Text style={s.brand}>Super <Text style={{color:blue}}>Connection</Text></Text><Text style={s.subtitle}>Connect with your community.</Text>{!supabase && <Text style={s.warning}>Backend not configured yet. Follow SETUP.md before using account features.</Text>}{mode === 'signup' && <TextInput style={s.input} placeholder="Username (3+ characters)" value={username} onChangeText={setUsername} autoCapitalize="none"/>}<TextInput style={s.input} placeholder="Email address" value={email} onChangeText={setEmail} keyboardType="email-address" autoCapitalize="none" autoCorrect={false}/><TextInput style={s.input} placeholder="Password (at least 8 characters)" value={password} onChangeText={setPassword} secureTextEntry/><TouchableOpacity style={s.primary} onPress={authenticate} disabled={busy}><Text style={s.primaryText}>{busy ? 'Please wait…' : mode === 'signup' ? 'Create secure account' : 'Sign in'}</Text></TouchableOpacity><TouchableOpacity onPress={() => setMode(mode === 'signup' ? 'signin' : 'signup')}><Text style={s.link}>{mode === 'signup' ? 'Already have an account? Sign in' : 'New here? Create an account'}</Text></TouchableOpacity><Text style={s.small}>Use a unique password. Email confirmation and password-reset settings must be enabled in Supabase.</Text></ScrollView></SafeAreaView>;

  return <SafeAreaView style={s.safe}><View style={s.header}><View><Text style={s.brandSmall}>Super <Text style={{color:blue}}>Connection</Text></Text><Text style={s.muted}>A place to belong.</Text></View><TouchableOpacity onPress={() => supabase?.auth.signOut()}><Text style={s.link}>Sign out</Text></TouchableOpacity></View>
    <ScrollView style={{flex:1}} contentContainerStyle={{padding:14,paddingBottom:30}}>
      {tab === 'Feed' && <><Text style={s.heading}>Your feed</Text><TextInput style={[s.input,{minHeight:85,textAlignVertical:'top'}]} placeholder="What's happening?" value={draft} onChangeText={setDraft} multiline/><View style={s.row}><TouchableOpacity style={s.primarySmall} onPress={publish}><Text style={s.primaryText}>Publish post</Text></TouchableOpacity><TouchableOpacity style={s.secondary} onPress={uploadMedia}><Text style={s.secondaryText}>Photo / video</Text></TouchableOpacity></View>{posts.map(p => <View key={p.id} style={s.card}><Text style={s.person}>{p.profiles?.display_name || p.profiles?.username || 'Community member'}</Text><Text style={s.body}>{p.body}</Text>{p.media_url ? <Image source={{uri:p.media_url}} style={s.media} resizeMode="cover"/> : null}<Text style={s.muted}>{new Date(p.created_at).toLocaleString()}</Text><View style={s.row}><TouchableOpacity onPress={() => reportUser(p.user_id)}><Text style={s.link}>Report author</Text></TouchableOpacity><TouchableOpacity onPress={() => blockUser(p.user_id)}><Text style={s.danger}>Block author</Text></TouchableOpacity></View></View>)}{!posts.length && <Text style={s.muted}>No posts yet. Be the first to post.</Text>}</>}
      {tab === 'Friends' && <><Text style={s.heading}>Friend requests</Text>{requests.map(r => <View key={r.id} style={s.card}><Text style={s.person}>{r.profiles?.display_name || r.profiles?.username || 'Member'}</Text><View style={s.row}><TouchableOpacity style={s.primarySmall} onPress={() => answerRequest(r.id,'accepted')}><Text style={s.primaryText}>Accept</Text></TouchableOpacity><TouchableOpacity style={s.secondary} onPress={() => answerRequest(r.id,'rejected')}><Text style={s.secondaryText}>Decline</Text></TouchableOpacity></View></View>)}<Text style={s.heading}>Discover members</Text>{people.map(p => <View key={p.id} style={s.card}><Text style={s.person}>{p.display_name || p.username}</Text><View style={s.row}><TouchableOpacity style={s.primarySmall} onPress={() => sendFriendRequest(p.id)}><Text style={s.primaryText}>Add friend</Text></TouchableOpacity><TouchableOpacity onPress={() => reportUser(p.id)}><Text style={s.link}>Report</Text></TouchableOpacity><TouchableOpacity onPress={() => blockUser(p.id)}><Text style={s.danger}>Block</Text></TouchableOpacity></View></View>)}</>}
      {tab === 'Messages' && <><Text style={s.heading}>Messages</Text><Text style={s.muted}>Conversations appear here once a conversation has been created. Friend-to-friend conversation creation can be added next.</Text>{conversations.map(c => <TouchableOpacity key={c.conversation_id} style={s.card} onPress={() => setActiveConversation(c.conversation_id)}><Text style={s.person}>Conversation {String(c.conversation_id).slice(0,8)}</Text><Text style={s.link}>Open chat</Text></TouchableOpacity>)}{activeConversation && <View style={s.card}><Text style={s.person}>Live chat</Text>{messages.map(m => <Text key={m.id} style={s.body}>{m.sender_id === session.user.id ? 'You: ' : 'Member: '}{m.body}</Text>)}<TextInput style={s.input} placeholder="Write a message" value={messageDraft} onChangeText={setMessageDraft}/><TouchableOpacity style={s.primary} onPress={sendMessage}><Text style={s.primaryText}>Send message</Text></TouchableOpacity></View>}</>}
      {tab === 'Privacy' && <><Text style={s.heading}>Privacy & safety</Text><Text style={s.body}>Privacy preferences</Text><Toggle label="Private profile" value={privateProfile} onChange={setPrivateProfile}/><Toggle label="Allow friend requests" value={allowRequests} onChange={setAllowRequests}/><TouchableOpacity style={s.primary} onPress={savePrivacy}><Text style={s.primaryText}>Save privacy settings</Text></TouchableOpacity><TouchableOpacity style={s.secondary} onPress={() => Alert.alert('Account deletion', 'Before launch, add a verified account-deletion workflow that deletes or anonymizes personal data and media. Contact the app administrator for this prototype.') }><Text style={s.secondaryText}>Account deletion information</Text></TouchableOpacity><Text style={s.small}>Reports are stored for moderator review. A human moderation queue, appeals, rate limits, and verified account deletion still need to be configured before public launch.</Text></>}
    </ScrollView><View style={s.nav}>{(['Feed','Friends','Messages','Privacy'] as Tab[]).map(t => <TouchableOpacity key={t} onPress={() => setTab(t)} style={s.navItem}><Text style={[s.navText,tab===t&&{color:blue,fontWeight:'800'}]}>{t}</Text></TouchableOpacity>)}</View></SafeAreaView>;
}
function Toggle({label,value,onChange}:{label:string;value:boolean;onChange:(v:boolean)=>void}) { return <TouchableOpacity style={s.toggle} onPress={() => onChange(!value)}><Text style={s.body}>{label}</Text><Text style={s.person}>{value ? 'ON' : 'OFF'}</Text></TouchableOpacity>; }
const s = StyleSheet.create({safe:{flex:1,backgroundColor:'#F3F6FB'},center:{flex:1,alignItems:'center',justifyContent:'center',gap:12,backgroundColor:'#F3F6FB'},auth:{flexGrow:1,justifyContent:'center',padding:24},brand:{fontSize:28,fontWeight:'900',color:'#14243A',textAlign:'center'},brandSmall:{fontSize:21,fontWeight:'900',color:'#14243A'},subtitle:{textAlign:'center',color:'#718096',marginTop:8,marginBottom:25},header:{paddingHorizontal:18,paddingVertical:12,backgroundColor:'#FFF',flexDirection:'row',alignItems:'center',justifyContent:'space-between',borderBottomWidth:1,borderColor:'#E8EDF4'},input:{backgroundColor:'#FFF',borderWidth:1,borderColor:'#DCE4EF',borderRadius:12,padding:13,marginBottom:10,color:'#17263B'},primary:{backgroundColor:blue,padding:14,borderRadius:12,alignItems:'center',marginVertical:8},primarySmall:{backgroundColor:blue,paddingHorizontal:15,paddingVertical:10,borderRadius:10},primaryText:{color:'#FFF',fontWeight:'800'},secondary:{backgroundColor:'#E8EEF8',paddingHorizontal:14,paddingVertical:10,borderRadius:10},secondaryText:{color:'#27405F',fontWeight:'700'},link:{color:blue,fontWeight:'700',paddingVertical:8},danger:{color:'#C03950',fontWeight:'700',paddingVertical:8},small:{fontSize:11,color:'#8995A5',lineHeight:17,marginTop:18,textAlign:'center'},warning:{color:'#9B4B00',backgroundColor:'#FFF1D8',padding:12,borderRadius:10,marginBottom:15,fontSize:12},muted:{fontSize:12,color:'#8793A5',marginTop:4},heading:{fontSize:22,fontWeight:'900',color:'#182A42',marginBottom:12,marginTop:8},card:{backgroundColor:'#FFF',borderRadius:14,padding:14,marginBottom:10,borderWidth:1,borderColor:'#E5EBF3'},person:{fontSize:14,fontWeight:'800',color:'#20324A'},body:{fontSize:14,color:'#43536A',lineHeight:21,marginVertical:7},media:{width:'100%',height:220,borderRadius:10,marginVertical:10},row:{flexDirection:'row',alignItems:'center',justifyContent:'space-between',gap:10,flexWrap:'wrap',marginTop:8},nav:{flexDirection:'row',backgroundColor:'#FFF',borderTopWidth:1,borderColor:'#E5EBF3',paddingVertical:12},navItem:{flex:1,alignItems:'center'},navText:{fontSize:12,color:'#8490A0'},toggle:{flexDirection:'row',justifyContent:'space-between',alignItems:'center',backgroundColor:'#FFF',padding:15,borderRadius:12,marginVertical:5,borderWidth:1,borderColor:'#E5EBF3'}});
