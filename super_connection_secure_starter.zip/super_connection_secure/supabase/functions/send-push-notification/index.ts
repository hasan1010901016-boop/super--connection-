// Deploy with Supabase CLI. Invoke with a notification_id that was created by trusted server logic.
// Configure SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, and EXPO_ACCESS_TOKEN as Edge Function secrets.
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
Deno.serve(async (req: Request) => {
  if (req.method !== 'POST') return new Response('Method not allowed', { status: 405 });
  const authHeader = req.headers.get('Authorization');
  if (!authHeader) return new Response('Unauthorized', { status: 401 });
  const url = Deno.env.get('SUPABASE_URL')!;
  const serviceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
  const expoAccessToken = Deno.env.get('EXPO_ACCESS_TOKEN');
  const admin = createClient(url, serviceKey);
  const userClient = createClient(url, Deno.env.get('SUPABASE_ANON_KEY')!, { global: { headers: { Authorization: authHeader } } });
  const { data: { user }, error: authError } = await userClient.auth.getUser();
  if (authError || !user) return new Response('Unauthorized', { status: 401 });
  const body = await req.json().catch(() => ({}));
  if (typeof body.notification_id !== 'string') return new Response('notification_id required', { status: 400 });
  const { data: notification, error } = await admin.from('notifications').select('id,user_id,actor_id,kind').eq('id', body.notification_id).single();
  if (error || !notification || notification.actor_id !== user.id || notification.user_id === user.id) return new Response('Forbidden', { status: 403 });
  const { data: tokens } = await admin.from('device_tokens').select('expo_push_token').eq('user_id', notification.user_id);
  if (!tokens?.length) return Response.json({ sent: 0, reason: 'no_device_tokens' });
  const actor = await admin.from('profiles').select('username,display_name').eq('id', user.id).maybeSingle();
  const messages = tokens.map(({ expo_push_token }) => ({ to: expo_push_token, sound: 'default', title: 'Super Connection', body: `${actor.data?.display_name || actor.data?.username || 'Someone'} sent you a notification`, data: { notificationId: notification.id, kind: notification.kind } }));
  const headers: Record<string,string> = { 'Content-Type': 'application/json', Accept: 'application/json' };
  if (expoAccessToken) headers.Authorization = `Bearer ${expoAccessToken}`;
  const result = await fetch('https://exp.host/--/api/v2/push/send', { method: 'POST', headers, body: JSON.stringify(messages) });
  const responseText = await result.text();
  if (!result.ok) return new Response(responseText, { status: 502 });
  return new Response(JSON.stringify({ sent: messages.length }), { headers: { 'Content-Type': 'application/json' } });
});
