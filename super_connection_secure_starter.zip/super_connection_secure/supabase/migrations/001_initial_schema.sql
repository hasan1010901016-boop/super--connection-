-- Super Connection starter schema. Review with a security engineer before public launch.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique not null check (char_length(username) between 3 and 30),
  display_name text,
  bio text not null default '',
  avatar_path text,
  is_private boolean not null default false,
  allow_friend_requests boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create or replace function public.create_profile_for_new_user()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
  insert into public.profiles (id, username, display_name)
  values (new.id,
    coalesce(nullif(new.raw_user_meta_data->>'username',''), 'member_' || substr(new.id::text,1,8)),
    coalesce(nullif(new.raw_user_meta_data->>'username',''), 'New member'))
  on conflict (id) do nothing;
  return new;
end; $$;
drop trigger if exists on_auth_user_created_profile on auth.users;
create trigger on_auth_user_created_profile after insert on auth.users
for each row execute procedure public.create_profile_for_new_user();

create table if not exists public.posts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  body text not null default '' check (char_length(body) <= 5000),
  media_path text,
  moderation_status text not null default 'visible' check (moderation_status in ('visible','under_review','removed')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (char_length(body) > 0 or media_path is not null)
);
create index if not exists posts_created_at_idx on public.posts(created_at desc);
create index if not exists posts_user_id_idx on public.posts(user_id);

create table if not exists public.friend_requests (
  id uuid primary key default gen_random_uuid(),
  sender_id uuid not null references public.profiles(id) on delete cascade,
  receiver_id uuid not null references public.profiles(id) on delete cascade,
  status text not null default 'pending' check (status in ('pending','accepted','rejected','cancelled')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (sender_id <> receiver_id),
  unique(sender_id, receiver_id)
);

create table if not exists public.conversations (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now()
);
create table if not exists public.conversation_members (
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  joined_at timestamptz not null default now(),
  primary key(conversation_id, user_id)
);
create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  sender_id uuid not null references public.profiles(id) on delete cascade,
  body text not null check (char_length(body) between 1 and 5000),
  created_at timestamptz not null default now()
);
create index if not exists messages_conversation_created_idx on public.messages(conversation_id, created_at);

create table if not exists public.blocks (
  blocker_id uuid not null references public.profiles(id) on delete cascade,
  blocked_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key(blocker_id, blocked_id),
  check(blocker_id <> blocked_id)
);
create table if not exists public.reports (
  id uuid primary key default gen_random_uuid(),
  reporter_id uuid not null references public.profiles(id) on delete cascade,
  target_user_id uuid references public.profiles(id) on delete set null,
  target_post_id uuid references public.posts(id) on delete set null,
  reason text not null check(reason in ('spam','harassment','hate','sexual_content','violence','impersonation','other')),
  details text not null default '' check(char_length(details) <= 3000),
  status text not null default 'open' check(status in ('open','reviewing','actioned','dismissed')),
  moderator_notes text not null default '',
  created_at timestamptz not null default now(),
  check(target_user_id is not null or target_post_id is not null)
);
create table if not exists public.device_tokens (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  expo_push_token text unique not null,
  created_at timestamptz not null default now()
);
create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  actor_id uuid references public.profiles(id) on delete set null,
  kind text not null check(kind in ('friend_request','friend_accepted','message','comment','reaction','moderation')),
  entity_id uuid,
  read_at timestamptz,
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.posts enable row level security;
alter table public.friend_requests enable row level security;
alter table public.conversations enable row level security;
alter table public.conversation_members enable row level security;
alter table public.messages enable row level security;
alter table public.blocks enable row level security;
alter table public.reports enable row level security;
alter table public.device_tokens enable row level security;
alter table public.notifications enable row level security;

-- Profiles are discoverable in this starter. Add private-profile visibility checks before launch.
create policy "profiles authenticated read" on public.profiles for select to authenticated using (true);
create policy "profile owner updates own" on public.profiles for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);
create policy "profile owner inserts own" on public.profiles for insert to authenticated with check (auth.uid() = id);

create policy "read visible posts" on public.posts for select to authenticated using (
 moderation_status = 'visible' and not exists(select 1 from public.blocks b where (b.blocker_id = auth.uid() and b.blocked_id = user_id) or (b.blocker_id = user_id and b.blocked_id = auth.uid()))
);
create policy "create own post" on public.posts for insert to authenticated with check (auth.uid() = user_id);
create policy "update own post" on public.posts for update to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "delete own post" on public.posts for delete to authenticated using (auth.uid() = user_id);

create policy "request participants read" on public.friend_requests for select to authenticated using (auth.uid() = sender_id or auth.uid() = receiver_id);
create policy "send own friend request" on public.friend_requests for insert to authenticated with check (auth.uid() = sender_id and not exists(select 1 from public.blocks b where (b.blocker_id = sender_id and b.blocked_id = receiver_id) or (b.blocker_id = receiver_id and b.blocked_id = sender_id)));
create policy "receiver can update request" on public.friend_requests for update to authenticated using (auth.uid() = receiver_id) with check (auth.uid() = receiver_id);
create policy "sender can cancel request" on public.friend_requests for delete to authenticated using (auth.uid() = sender_id);

create policy "conversation members read conversations" on public.conversations for select to authenticated using (exists(select 1 from public.conversation_members cm where cm.conversation_id = id and cm.user_id = auth.uid()));
create policy "members read membership" on public.conversation_members for select to authenticated using (exists(select 1 from public.conversation_members cm where cm.conversation_id = conversation_id and cm.user_id = auth.uid()));
create policy "member reads messages" on public.messages for select to authenticated using (exists(select 1 from public.conversation_members cm where cm.conversation_id = messages.conversation_id and cm.user_id = auth.uid()));
create policy "member sends own message" on public.messages for insert to authenticated with check (auth.uid() = sender_id and exists(select 1 from public.conversation_members cm where cm.conversation_id = messages.conversation_id and cm.user_id = auth.uid()));

create policy "users read own blocks" on public.blocks for select to authenticated using (auth.uid() = blocker_id);
create policy "users create own blocks" on public.blocks for insert to authenticated with check (auth.uid() = blocker_id);
create policy "users remove own blocks" on public.blocks for delete to authenticated using (auth.uid() = blocker_id);
create policy "users create reports" on public.reports for insert to authenticated with check (auth.uid() = reporter_id);
create policy "reporters see own reports" on public.reports for select to authenticated using (auth.uid() = reporter_id);
create policy "users manage own tokens" on public.device_tokens for select to authenticated using (auth.uid() = user_id);
create policy "users add own tokens" on public.device_tokens for insert to authenticated with check (auth.uid() = user_id);
create policy "users update own tokens" on public.device_tokens for update to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "users delete own tokens" on public.device_tokens for delete to authenticated using (auth.uid() = user_id);
create policy "users read own notifications" on public.notifications for select to authenticated using (auth.uid() = user_id);
create policy "users update own notifications" on public.notifications for update to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- Private bucket: use signed URLs; never expose media through a public bucket by default.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('post-media','post-media',false,26214400,array['image/jpeg','image/png','image/webp','video/mp4','video/quicktime'])
on conflict (id) do update set public = false, file_size_limit = 26214400;
create policy "authenticated upload to own media folder" on storage.objects for insert to authenticated with check (bucket_id = 'post-media' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "authenticated read media for prototype" on storage.objects for select to authenticated using (bucket_id = 'post-media');
create policy "users delete own media" on storage.objects for delete to authenticated using (bucket_id = 'post-media' and (storage.foldername(name))[1] = auth.uid()::text);

-- Enable Realtime for message inserts (run once; if already added, ignore duplicate membership error).
do $$ begin alter publication supabase_realtime add table public.messages; exception when duplicate_object then null; end $$;
