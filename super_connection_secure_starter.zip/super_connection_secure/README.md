# Super Connection — secure-backend starter (Expo + Supabase)

This is a development starter for the Super Connection Android social app. It adds a Supabase integration scaffold for authentication, a cloud database, friend requests, realtime message subscriptions, private media storage, push-token registration, privacy preferences, user blocking, and abuse reports.

**Important: this is not production-ready and must not be opened to the public yet.** Security policies are a baseline, not a complete audit. Private-profile visibility, conversation creation, notification creation/delivery workflow, moderator tooling, rate limiting, and verified account deletion still need implementation and testing. Do not use real users' sensitive data until these steps are finished.

## Included

- Email/password registration and sign-in using Supabase Auth.
- Cloud tables and row-level security policies in `supabase/migrations/001_initial_schema.sql`.
- Feed reads and authenticated post creation.
- Friend request send / accept / decline.
- Realtime subscription for messages in an existing conversation.
- Private Storage bucket and authenticated photo/video upload (25 MB limit, MIME allow-list).
- Expo push-token registration and a starter Edge Function for sending a push notification from a trusted notification record.
- Privacy preference fields, report records, and block records.

## Setup

1. Install Node.js 20+ on a computer, install Expo Go on your Android phone, and unzip this project.
2. Create a project at Supabase. In **Project Settings → API**, copy the Project URL and the publishable/anon key.
3. Copy `.env.example` to `.env` and fill in `EXPO_PUBLIC_SUPABASE_URL` and `EXPO_PUBLIC_SUPABASE_ANON_KEY`. These are public client values; **never put the service-role key in the app**.
4. In the Supabase SQL Editor, run `supabase/migrations/001_initial_schema.sql`.
5. In Supabase Authentication settings, enable email confirmation and configure your allowed redirect/site URLs and password recovery flow.
6. In Supabase Dashboard → Storage, confirm the `post-media` bucket is private. The migration creates it with a 25 MB limit.
7. Run `npm install`, then `npx expo start`, and scan the QR code with Expo Go.

## Push notifications

Push-token registration is scaffolded. Real push delivery requires a development/production device build, correct Expo project configuration, and a trusted server workflow. Deploy `supabase/functions/send-push-notification` using the Supabase CLI, set its secrets (`SUPABASE_URL`, `SUPABASE_ANON_KEY`, `SUPABASE_SERVICE_ROLE_KEY`, and optionally `EXPO_ACCESS_TOKEN`), and invoke it only after trusted server-side logic creates a notification record. Never ship the service-role key to the phone. Test on a physical device; push behavior differs in Expo Go and simulator environments.

## Important current limitations

- Conversation creation and a UI to start a new chat are not implemented yet; realtime messaging works only after a valid conversation and membership records exist.
- The UI does not yet show private profiles according to `is_private`; the database schema stores the setting but profile discovery policies must be tightened before launch.
- Push tokens are registered, but this starter does not automatically create notifications for every event. Build trusted database/Edge Function triggers for friend requests, messages, reports, etc.
- Report submission is available from the starter UI, but there is no moderator dashboard or automated review queue. Only trusted administrators should be allowed to read all reports and change moderation status.
- Account deletion, content appeals, spam/rate limits, age policy, consent, retention rules, and incident response are not complete.
- Media access uses signed URLs for feed rendering. Revisit Storage policies if you need private posts or friends-only visibility.
- The SQL policy allowing authenticated users to read uploaded media is intentionally marked as a prototype convenience; tighten it to match post visibility before public launch.
- Friend request status updates need a stricter server-side transition check (receiver may only accept/reject pending requests) before public launch.

## Before public launch — required checklist

- [ ] Apply least-privilege RLS to every table and Storage object; test as anonymous, normal user, blocked user, and moderator.
- [ ] Enforce private-profile and audience rules in queries and RLS, not only in the UI.
- [ ] Add conversation creation with membership verification; ensure only participants can read/write messages.
- [ ] Add push event triggers, token invalidation, rate limiting, and abuse prevention.
- [ ] Add moderator dashboard, audit trail, report triage, removal/suspension tools, appeal process, and emergency escalation.
- [ ] Add verified account/data deletion and media cleanup; write a privacy policy and terms of service.
- [ ] Validate file MIME/type/size server-side, scan uploads where practical, and prevent executable or abusive uploads.
- [ ] Add tests for authorization boundaries, automated security checks, backups, monitoring, and incident response.
- [ ] Perform an independent security review before inviting the public.

## Security notes

Passwords are handled by Supabase Auth. The mobile app uses only the public anon/publishable key and relies on Row Level Security. Never disable RLS on user data tables and never put a Supabase service-role key in `.env` variables prefixed with `EXPO_PUBLIC_`.
